@extends('layout.app')

@section('main_content')
    <a href="#">Tropang EMB</a>
@endsection
@section('sub_content')
    Yow
@endsection