@extends('auth.app')

@section('content')
        <div class="ui container" style="height:100%; border:solid 1px">
            <div class="ui card centered" style="margin:auto;position:relative">
                <div class="content">
                    Shitty Loads
                </div>
            </div>
        </div>
@endsection