<link rel="stylesheet" type="text/css" href="{{ url('plugins/semantic/semantic.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{ url('customs/css/system.css')}}">