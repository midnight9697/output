<script
  src="{{ url('plugins/jquery/jquery-3.1.1.min.js') }}"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script src="{{url('plugins/semantic/semantic.min.js')}}"></script>
<script src="{{url('customs/js/system.js')}}"></script>