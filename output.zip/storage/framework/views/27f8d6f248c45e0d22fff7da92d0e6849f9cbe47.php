

<?php $__env->startSection('main_content'); ?>
    <a href="#">Tropang EMB</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub_content'); ?>
    Yow
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev Projects\Mine\output\resources\views/admin/home.blade.php ENDPATH**/ ?>