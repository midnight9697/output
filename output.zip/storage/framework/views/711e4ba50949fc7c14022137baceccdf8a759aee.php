

<?php $__env->startSection('content'); ?>
        <div class="ui container" style="height:100%; border:solid 1px">
            <div class="ui card centered" style="margin:auto;position:relative">
                <div class="content">
                    ShittY LOAD
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev Projects\Mine\output\resources\views/auth/login.blade.php ENDPATH**/ ?>